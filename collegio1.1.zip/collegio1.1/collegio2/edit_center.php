<?php
include('inc/db.php');
include("inc/auth_session.php");
include("inc/getrole.php");
?>
<!DOCTYPE html>
<html lang="en">
   <!-- head html Topbar -->
   <?php
        include 'inc/head.php';
        ?>
   

    <body>

       <!-- Begin page -->
       <div id="wrapper">
 
 
 <!-- start Topbar -->
 <?php
 include 'inc/topbar.php';
 ?>

   <!-- end Topbar -->

   <!-- ========== Left Sidebar Start ========== -->
 <?php
 if ($UserROLE == 'ADMIN') {

 include 'inc/left-nav.php';

} elseif ($UserROLE == 'CENTER') {
     include 'inc/left-nav-centers.php';
 } else {

 }

 ?>     
 
 <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">

                                    <h4 class="page-title">Modifica Studente</h4>

                                </div>



                            </div>
                        </div>
                        <!-- end page title -->

                    </div> <!-- end container-fluid -->

                    <div class="col-12">
                                                    <div class="card-box">

                                                        <h4 class="header-title mb-4">Modifica Studente</h4>


                                                        <div class="card-box">


                                               <!-- Code UPDATE CENTER START -->

                                               <?php
                                                                                     
                                                            if(isset($_POST['updateaddcenter']))
                                                            {
                                                                if(isset($_POST['nome'])) {  $nome = $_POST['nome'];}
                                                                if(isset($_POST['cognome'])) {  $cognome = $_POST['cognome'];}
                                                                if(isset($_POST['IDStudente'])) {  $studente_id = $_POST['IDStudente'];}
                                                                if(isset($_POST['username'])) {  $username = $_POST['username'];}
                                                                if(isset($_POST['email'])) {  $email = $_POST['email'];}
                                                                if(isset($_POST['password'])) {  $password = $_POST['password'];}
                                                                $query1="UPDATE studenti SET nome='$nome', cognome='$cognome', IDStudente='$IDStudente', username='$username', email='$email', password='$password' WHERE IDStudente = '$studente_id'";
                                                                
                                                                
                                                            
                                                            
                                                            
                                                                if ( ! $conn->query($query1)) {
                                                                    // Creazione fallita 
                                                                    echo " Errore  nella cancellazione dell ' utente   $query1  ";
                                                                    }  else {
                                                                        echo " Studente modificato   ";
                                                            
                                                                    }
                                                            }
                                                                mysqli_close($conn);
                                                                                     
                                                ?>

                                                       <!-- Code UPDATE CENTER END -->




                                                       <div class="row">
                                                            <div class="col-xl-6">
                                                              <form method="post" action="<?=($_SERVER['PHP_SELF'])?>" >

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Nome</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="Nome" name="nome">

                                                                    </small>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Cognome</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="Cognome" name="cognome">

                                                                    </small>
                                                                </div>


                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">ID</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="ID-Studente" name="IDStudente">

                                                                        </small>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Username</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="Username" name="username">

                                                                        </small>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail">Email</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="Email" name="email">
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword1">Password</label>
                                                                        <input class="form-control mb-3" type="password" placeholder="Password" name="password">
                                                                    </div>

                                                                    <button type="submit" class="btn btn-primary" name="updateaddcenter">Salva</button>
                                                                    <button onclick="window.location.href='centers.php'" type="button"  class="btn btn-danger " >
                                                                        <span class="btn-label"  >
                                                                    </span>Annulla</button>
                                                              </form>
                                                            </div><!-- end col -->

                                                            <div class="col-xl-6">

                                                            </div><!-- end col -->

                                                        </div><!-- end row -->
                                                    </div>
                                                </div>






                </div> <!-- end content -->



                <!-- Footer Start -->
                <?php
                    include 'inc/footer.php';
                 ?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->



        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>



        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>


                <!-- Datatable plugin js -->
                <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
                <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
                <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
                <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

                <script src="assets/libs/jszip/jszip.min.js"></script>
                <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
                <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

                <script src="assets/libs/datatables/buttons.html5.min.js"></script>
                <script src="assets/libs/datatables/buttons.print.min.js"></script>

                <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
                <script src="assets/libs/datatables/dataTables.select.min.js"></script>

                <!-- Datatables init -->
                <script src="assets/js/pages/datatables.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>
