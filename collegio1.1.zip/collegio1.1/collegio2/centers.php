<?php
require('inc/db.php');
include("inc/auth_session.php");
include("inc/getrole.php");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Lista Studenti</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Responsive bootstrap 4 admin template" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css"  id="app-stylesheet" />
        <?php
        $sql = "SELECT IDStudente,nome,cognome,username FROM studenti";

        $query = mysqli_query($conn, $sql);

        if (!$query) {
        die ('SQL Error: ' . mysqli_error($conn));
        }
        ?>
    </head>

    <body>

      <!-- Begin page -->
      <div id="wrapper">
 
 
 <!-- start Topbar -->
 <?php
 include 'inc/topbar.php';
 ?>

   <!-- end Topbar -->

   <!-- ========== Left Sidebar Start ========== -->
 <?php
 if ($UserROLE == 'ADMIN') {

 include 'inc/left-nav.php';

} elseif ($UserROLE == 'CENTER') {
     include 'inc/left-nav-centers.php';
 } else {

 }

 ?>     
 
 <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">

                                    <h4 class="page-title">Lista Studenti</h4>

                                </div>



                            </div>
                        </div>
                        <!-- end page title -->

                    </div> <!-- end container-fluid -->

                    <!-- Start table -->
                     <div class="row">
                         <div class="col-12">
                             <div class="card-box">
                               <div>
                              <button onclick="window.location.href='new_centers.php'" type="button"  class="btn btn-success waves-effect waves-light" >
                              <span class="btn-label"  ><i class="ion ion-md-add" ></i>
                              </span>Inserisci studente</button>
                                </div>
                                 <p class="sub-header">
                                 </p>

                                 <table  class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                     <thead>
                                      <tr>
                                         <th>ID</th>
                                         <th>Nome</th>
                                         <th>Cognome</th>
                                         <th>Username</th>
                                         <th>Modifica</th>
                                     </tr>
                                     </thead>


                                     <tbody>
                                       <?php
                                        while ($row = mysqli_fetch_array($query))
                                        {
                                  echo '<tr>
                                         <td>'.$row['IDStudente'].'</td>
                                         <td>'.$row['nome'].'</td>
                                         <td>'.$row['cognome'].'</td>
                                         <td>'.$row['username'].'</td>
                                         <td>
                                        <a href="edit_center.php?User_id='.$row['User_id'].'"  class="btn waves-effect waves-light btn-info"><i class="fas fa-edit"></i></a>
                                        <a href="delete_center.php?User_id='.$row['User_id'].'"  class="btn waves-effect waves-light btn-danger"><i class="fas fa-trash-alt"></i></a>

                                         </td>
                                     </tr>';
                                   	}?>

                                     </tbody>
                                 </table>
                             </div>
                         </div>
                     </div>
                     <!-- End table -->



                </div> <!-- end content -->


 <!-- Footer Start -->
 <?php
                    include 'inc/footer.php';
                 ?>
                <!-- end Footer -->
            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->



        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>



        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>


                <!-- Datatable plugin js -->
                <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
                <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
                <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
                <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

                <script src="assets/libs/jszip/jszip.min.js"></script>
                <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
                <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

                <script src="assets/libs/datatables/buttons.html5.min.js"></script>
                <script src="assets/libs/datatables/buttons.print.min.js"></script>

                <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
                <script src="assets/libs/datatables/dataTables.select.min.js"></script>

                <!-- Datatables init -->
                <script src="assets/js/pages/datatables.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>
