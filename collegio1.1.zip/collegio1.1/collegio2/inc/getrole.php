<?php
$usernameSESSIONE = $_SESSION['username'];
$sql = "SELECT * FROM `UsersRoles` WHERE Username='$usernameSESSIONE'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
 // output data of each row
 while($row = $result->fetch_assoc()) {

   $UserID = $row["User_id"];
   $UserROLE = $row["User_ROLE"];
   $UserEMAIL = $row["User_email_address"];

 }
} else {
 echo "0 results";
}
//$conn->close();
?>
