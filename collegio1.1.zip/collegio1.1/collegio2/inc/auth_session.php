<?php
    session_start();
    if(!isset($_SESSION["username"])) {   // se la variabile di sessione non è settata chiedo il login 
        header("Location: ./auth/login.php");
        exit();
    }
?>
