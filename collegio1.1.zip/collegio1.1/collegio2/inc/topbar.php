  <!-- Topbar Start -->
  <div class="navbar-custom">

              <ul class="list-unstyled topnav-menu float-right mb-0">

               <li class="dropdown notification-list">
                      <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                          <span class="d-none d-sm-inline-block ml-1 font-weight-medium"><?php echo $_SESSION['username']; ?></span>
                          <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                      </a>
                      <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                       
                        

                          <div class="dropdown-divider"></div>

                          <!-- item-->
                          <a href="auth/logout.php" class="dropdown-item notify-item">
                              <i class="mdi mdi-logout-variant"></i>
                              <span>Logout</span>
                          </a>

                      </div>
                  </li>



              </ul>
 

              </ul>
          </div>
          
