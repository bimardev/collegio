<div class="left-side-menu">

    <div class="slimscroll-menu">

        <!--- Sidemenu -->
        <div id="sidebar-menu">

            <ul class="metismenu" id="side-menu">

                <li>
                    <a href="index.php">
                        <span> Dashboard </span>
                    </a>
                </li>

                <li>
                    <a href="centers.php">
                        <span> Studenti </span>
                    </a>
                </li>

                <li>
                    <a href="tests.php">
                        <span> Esami </span>
                    </a>
                </li>


                
                   <li>
                    <a href="auth/logout.php">
                        <span> Logout </span>
                    </a>
                    </li>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
