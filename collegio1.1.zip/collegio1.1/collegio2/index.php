<?php
require('inc/db.php'); // connessione DB
include("inc/auth_session.php"); // chiama la pagina login
include("inc/getrole.php");
?>

<?php

$Candidates = "SELECT * FROM studenti ";

if ($result1=mysqli_query($conn,$Candidates))
  {
  // Return the number of rows in result set
  $CandidatesROWS=mysqli_num_rows($result1);
 //  printf("Candidates Result set has %d rows.\n",$CandidatesROWS);
  // Free result set
  mysqli_free_result($result1);
  }


  $Tests = "SELECT * FROM esami ";

  if ($result2=mysqli_query($conn,$Tests))
    {
    // Return the number of rows in result set
    $TestsROWS=mysqli_num_rows($result2);
   //  printf("Tests Result set has %d rows.\n",$TestsROWS);
    // Free result set
    mysqli_free_result($result2);
    }



?>



<!DOCTYPE html>
<html lang="en">
   <!-- head html Topbar -->
   <?php
        include 'inc/head.php';
        ?>
   

    <body>

      <!-- Begin page -->
      <div id="wrapper">
 
 
 <!-- start Topbar -->
 <?php
 include 'inc/topbar.php';
 ?>

   <!-- end Topbar -->

   <!-- ========== Left Sidebar Start ========== -->
 <?php
 if ($UserROLE == 'ADMIN') {

 include 'inc/left-nav.php';

} elseif ($UserROLE == 'CENTER') {
     include 'inc/left-nav-centers.php';
 } else {

 }

 ?>     
 
 <!-- Left Sidebar End -->

 <?php
 if ($UserROLE == 'ADMIN') {

 include 'dashadmin.php';

} elseif ($UserROLE == 'CENTER') {
     include 'dashstudente.php';
 } else {

 }

 ?> 

        </div>
        <!-- END wrapper -->




        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>

        <!--Morris Chart-->
        <script src="assets/libs/morris-js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>

        <!-- Dashboard init js-->
        <script src="assets/js/pages/dashboard.init.js"></script>

        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>
