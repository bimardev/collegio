

<!DOCTYPE html>
<html lang="en">
    <head>



      <?php
          require('../inc/db.php');
          session_start();
          // When form submitted, check and create user session.
          if (isset($_POST['username'])) {
              $username = stripslashes($_REQUEST['username']);    // removes backslashes
              $username = mysqli_real_escape_string($conn, $username);
              $password = stripslashes($_REQUEST['password']);
              $password = mysqli_real_escape_string($conn, $password);
              // Check user is exist in the database
              $query    = "SELECT * FROM `UsersRoles` WHERE Username='$username' AND User_password='" . md5($password) . "' AND Account_Status='Attivo'";
          //    $query    = "SELECT * FROM `UsersRoles` WHERE Username='$username' AND User_password='$password' AND Account_Status='Attivo'";
          
      /*     echo "$query";
             exit;  */ 

              $result = mysqli_query($conn, $query) ;
              $rows = mysqli_num_rows($result);
              if ($rows == 1) {

                  $_SESSION['username'] = $username;            // la variabile di sessione a username
                  $_SESSION['user_role'] = $rows['user_role'];  // la variabile di sessione a username

                  // Redirect to user dashboard page
                  header("Location: ../index.php");


              }
              else {

                $_SESSION['errMsg'] = "Invalid username or password";
                header("location: login.php"); //send user back to the login page.
                echo '<h3>Invalid username or password</h3>';
              }

}

      ?>

        <meta charset="utf-8" />
        <title>Università</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Responsive bootstrap 4 admin template" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
        <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css"  id="app-stylesheet" />

    </head>

    <body class="authentication-bg">

        <div class="account-pages pt-5 my-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        <div class="account-card-box">
                            <div class="card mb-0">
                                <div class="card-body p-4">

                                    <div class="text-center">
                                        <div class="my-3">
                                            <a href="../index.php">
                                            <h3>Benvenuto!</h3>
                                            </a>
                                        </div>
                                        <h5 class="text-muted text-uppercase py-3 font-16">Accedi alla tua area</h5>

                                        <div id="errMsg">
                                            <?php if(!empty($_SESSION['errMsg'])) { echo $_SESSION['errMsg']; } ?>
                                        </div>
                                         <?php unset($_SESSION['errMsg']); ?>
                                    </div>

                                    <form method="post" action="<?=($_SERVER['PHP_SELF'])?>" name="login" class="mt-2">

                                        <div class="form-group mb-3">
                                            <input class="form-control" type="text" required="" id="username" name="username" placeholder="Username">
                                        </div>

                                        <div class="form-group mb-3">
                                            <input class="form-control" type="password" required="" id="password" name="password" placeholder="Password">
                                        </div>

                                        <div class="form-group text-center">
                                            <button class="btn btn-success btn-block waves-effect waves-light" type="submit" value="Login" name="submit"> Log In </button>
                                        </div>

                                    </form>


                                </div> <!-- end card-body -->
                            </div>
                            <!-- end card -->
                        </div>


                        <!-- end row -->

                    </div> <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->

        <!-- Vendor js -->
        <script src="../assets/js/vendor.min.js"></script>

        <!-- App js -->
        <script src="../assets/js/app.min.js"></script>

    </body>
</html>
<?php
    unset($_SESSION["error"]);
?>
