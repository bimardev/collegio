<?php
include('inc/db.php');
include("inc/auth_session.php");
include("inc/getrole.php");
?>
<!DOCTYPE html>
<html lang="en">
   <!-- head html Topbar -->
   <?php
        include 'inc/head.php';
        ?>
   

    <body>

       <!-- Begin page -->
       <div id="wrapper">
 
 
 <!-- start Topbar -->
 <?php
 include 'inc/topbar.php';
 ?>

   <!-- end Topbar -->

   <!-- ========== Left Sidebar Start ========== -->
 <?php
 if ($UserROLE == 'ADMIN') {

 include 'inc/left-nav.php';

} elseif ($UserROLE == 'CENTER') {
     include 'inc/left-nav-centers.php';
 } else {

 }

 ?>     
 
 <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">

                                    <h4 class="page-title">Esami</h4>

                                </div>



                            </div>
                        </div>
                        <!-- end page title -->

                    </div> <!-- end container-fluid -->

                    <div class="col-12">
                                                    <div class="card-box">

                                                        <h4 class="header-title mb-4">Inserisci nuovo esame </h4>

                                               <!-- Code INSERT CATEGORY START -->
                                                        <?php
                                                            // When form submitted, insert values into the database.
                                                        if(isset($_POST['createtest']))
                                                       {

                                                      //escapes special characters in a string
                                                      $IDStudente_POST=$_POST['IDStudente'];
                                                      $corso_POST=$_POST['corso'];
                                                      $esito_POST=$_POST['esito'];


                                                      $sql  = "INSERT into `esami` (IDStudente, corso, esito) VALUES ('$IDStudente_POST', '$corso_POST', '$esito_POST')";

                                                            if ($conn->query($sql) === TRUE) {
                                                          echo  "<h2><font color='green' style='font-size:15px'>Test Created</font></h2>";
                                                        echo "<script type='text/javascript'>window.top.location='tests.php';</script>"; exit;
                                                          // Upload file

                                                          } else {
                                                            echo "Error: " . $sql . "<br>" . $conn->error;
                                                          }



                                                      }

                                                      //    $conn->close();
                                                        ?>
                                                       <!-- Code INSERT CATEGORY END -->

                                                        <div class="row">
                                                            <div class="col-xl-6">
                                                              <form method="post" action="<?=($_SERVER['PHP_SELF'])?>" >



                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">ID Studente</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="ID" name="IDStudente">

                                                                    </small>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Corso</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="Corso" name="corso">

                                                                    </small>
                                                                </div>


                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Esito</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="Esito" name="esito">

                                                                        </small>
                                                                    </div>


                                                                    <button type="submit" class="btn btn-primary" name="createtest">Inserisci esame</button>
                                                                    <button onclick="window.location.href='tests.php'" type="button"  class="btn btn-danger " >
                                                                        <span class="btn-label"  >
                                                                    </span>Annulla</button>
                                                                
                                                              </form>
                                                            </div><!-- end col -->

                                                            <div class="col-xl-6">

                                                            </div><!-- end col -->

                                                        </div><!-- end row -->
                                                    </div>
                                                </div>






                </div> <!-- end content -->



             <!-- Footer Start -->
             <?php
                    include 'inc/footer.php';
                 ?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->



        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>



        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>


                <!-- Datatable plugin js -->
                <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
                <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
                <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
                <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

                <script src="assets/libs/jszip/jszip.min.js"></script>
                <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
                <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

                <script src="assets/libs/datatables/buttons.html5.min.js"></script>
                <script src="assets/libs/datatables/buttons.print.min.js"></script>

                <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
                <script src="assets/libs/datatables/dataTables.select.min.js"></script>

                <!-- Datatables init -->
                <script src="assets/js/pages/datatables.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

        <!-- include libraries(jQuery, bootstrap) -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <!-- include summernote css/js -->
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

        <script>
          $(document).ready(function() {
              $('#testdesc').summernote();

            //  $('#footer').summernote();
          });
        </script>
    </body>
</html>
