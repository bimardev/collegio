<?php
include('inc/db.php');
include("inc/auth_session.php");
include("inc/getrole.php");
?>
<!DOCTYPE html>
<html lang="en">
   <!-- head html Topbar -->
   <?php
        include 'inc/head.php';
        ?>
   

    <body>

    <!-- Begin page -->
    <div id="wrapper">
 
 
 <!-- start Topbar -->
 <?php
 include 'inc/topbar.php';
 ?>

   <!-- end Topbar -->

   <!-- ========== Left Sidebar Start ========== -->
 <?php
 if ($UserROLE == 'ADMIN') {

 include 'inc/left-nav.php';

} elseif ($UserROLE == 'CENTER') {
     include 'inc/left-nav-centers.php';
 } else {

 }

 ?>     
 
 <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">

                                    <h4 class="page-title">Nuovo studente</h4>

                                </div>



                            </div>
                        </div>
                        <!-- end page title -->

                    </div> <!-- end container-fluid -->

                    <div class="col-12">
                                                    <div class="card-box">

                                                        <h4 class="header-title mb-4">Inserisci nuovo studente</h4>

                                               <!-- Code INSERT CENTER START -->

                                               <?php

                                               if ( isset( $_POST['addcenter'] ) ) {

                                                 $nome=$_POST['nome'];
                                                 $cognome=$_POST['cognome'];
                                                 $Center_Phone=$_POST['Center_Phone'];
                                                 $IDStudente=$_POST['IDStudente'];
                                                 $username=$_POST['username'];
                                                 $email=$_POST['email'];
                                                 $password=$_POST['password'];
                                                 $User_Role='CENTER';
                                                 $create_datetime = date("Y-m-d H:i:s");


                                               $sql1 = "SELECT User_email_address FROM UsersRoles WHERE User_email_address='$email'";
                                               $result = $conn->query($sql1);

                                               if ($result->num_rows > 0) {
                                                 // output data of each row
                                                 while($row = $result->fetch_assoc()) {

                                                   echo "This Email Already Registred in our DATABASE !";
                                                 }
                                               } else {


                                               //Command to insert into table
                                               $sql = "INSERT INTO UsersRoles (Username, User_password, User_email_address, Account_created_on,User_ROLE) VALUES
                                               ('$username', '" . md5($password) . "', '$email', '$create_datetime','$User_Role')";
                                               if ($conn->query($sql) === TRUE) {


                                               $Center_ID = $conn->insert_id;

                                                 $sql2 = "INSERT INTO studenti (IDStudente, nome, cognome, username, email, password) VALUES
                                                ('$IDStudente', '$nome', '$cognome', '$username','$email', '$password')";
                                                if ($conn->query($sql2) === TRUE) {

                                                }


                                                 echo '<script>window.location = "centers.php"</script>';

                                               }

                                                else {
                                                 echo "Error: " . $sql2 . "<br>" . $conn->error;

                                               }

                                                }
                                                }
                                               ?>

                                                       <!-- Code INSERT CENTER END -->

                                                        <div class="row">
                                                            <div class="col-xl-6">
                                                                <form method="post" action="<?=($_SERVER['PHP_SELF'])?>" >

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Nome</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="Nome" name="nome">

                                                                    </small>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Cognome</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="Cognome" name="cognome">

                                                                    </small>
                                                                </div>

                                                                <!-- <div class="form-group">
                                                                    <label for="exampleInputEmail1">Phone</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="Phone" name="Center_Phone">

                                                                    </small>
                                                                </div> -->

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">ID</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="ID-Studente" name="IDStudente">

                                                                        </small>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Username</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="Username" name="username">

                                                                        </small>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail">Email</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="Email" name="email">
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <label for="exampleInputPassword1">Password</label>
                                                                        <input class="form-control mb-3" type="password" placeholder="Password" name="password">
                                                                    </div>

                                                                    <button type="submit" class="btn btn-primary" name="addcenter">Aggiungi studente</button>
                                                                    <button onclick="window.location.href='centers.php'" type="button"  class="btn btn-danger " >
                                                                        <span class="btn-label"  >
                                                                    </span>Annulla</button>
                                                                </form>
                                                            </div><!-- end col -->

                                                            <div class="col-xl-6">

                                                            </div><!-- end col -->

                                                        </div><!-- end row -->
                                                    </div>
                                                </div>






                </div> <!-- end content -->



            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->



        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>



        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>


                <!-- Datatable plugin js -->
                <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
                <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
                <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
                <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

                <script src="assets/libs/jszip/jszip.min.js"></script>
                <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
                <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

                <script src="assets/libs/datatables/buttons.html5.min.js"></script>
                <script src="assets/libs/datatables/buttons.print.min.js"></script>

                <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
                <script src="assets/libs/datatables/dataTables.select.min.js"></script>

                <!-- Datatables init -->
                <script src="assets/js/pages/datatables.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>
