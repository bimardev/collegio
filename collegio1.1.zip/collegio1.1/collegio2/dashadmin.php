            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
 
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        <h3 style = "text-align:center";><?php echo $_SESSION['username']; ?>, benvenuto nella tua area personale</h3>
                        <br><br>
                        <div class="row">
                            <div class="col-md-6 col-xl-4">
                                <div class="card-box tilebox-one">
                                    <i class="fas fa-book float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Studenti</h6>
                                    <h3 class="my-3" data-plugin="counterup"><?php echo $CandidatesROWS; ?></h3>
                                    <span class="badge badge-success mr-1"> </span> <span class="text-muted" onclick="window.location.href='centers.php';">Lista</span>
                                </div>
                            </div>

                            <div class="col-md-6 col-xl-4">
                                <div class="card-box tilebox-one">
                                    <i class="fas fa-file-contract float-right m-0 h2 text-muted"></i>
                                    <h6 class="text-muted text-uppercase mt-0">Esami</h6>
                                    <h3 class="my-3"><span data-plugin="counterup"><?php echo $TestsROWS; ?></span></h3>
                                    <span class="badge badge-success mr-1"> </span> <span class="text-muted" onclick="window.location.href='tests.php';">Lista</span>
                                </div>
                            </div>


                    </div> <!-- end container-fluid -->

                </div> <!-- end content -->



            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->