<?php
include('inc/db.php');
include("inc/auth_session.php");
include("inc/getrole.php");
?>
<!DOCTYPE html>
<html lang="en">
    <!-- head html Topbar -->
    <?php
        include 'inc/head.php';
        ?>
   

    <body>

     <!-- Begin page -->
     <div id="wrapper">
 
 
 <!-- start Topbar -->
 <?php
 include 'inc/topbar.php';
 ?>

   <!-- end Topbar -->

   <!-- ========== Left Sidebar Start ========== -->
 <?php
 if ($UserROLE == 'ADMIN') {

 include 'inc/left-nav.php';

} elseif ($UserROLE == 'CENTER') {
     include 'inc/left-nav-centers.php';
 } else {

 }

 ?>     
 
 <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">

                                    <h4 class="page-title">Elimina Studente</h4>

                                </div>



                            </div>
                        </div>
                        <!-- end page title -->

                    </div> <!-- end container-fluid -->

                        <?php
                        if(isset($_POST['deletecenter']))
                        {
                            if(isset($_POST['username'])) {  $username_id = $_POST['username'];}
                            $query1=" DELETE FROM studenti WHERE username ='$username_id'";
                            
                            
                        
                        
                        
                            if ( ! $conn->query($query1)) {
                                // Creazione fallita 
                                echo " Errore  nella cancellazione dell ' utente   $query1  ";
                                }  else {
                                    echo " Studente eliminato   ";
                        
                                }
                        }
                            mysqli_close($conn);
                        ?>


                    <div class="col-12">
                                                    <div class="card-box">

                                                        <h4 class="header-title mb-4">Elimina Studente</h4>


                                                        <div class="card-box">
                                                                <form method="post" action="<?=($_SERVER['PHP_SELF'])?>" >
                                                                  <input type="text" name="username" placeholder="Username Studente">
                                                                  <button type="submit" class="btn btn-primary" name="deletecenter">Elimina Studente</button>
                                                                  <button onclick="window.location.href='centers.php'" type="button"  class="btn btn-danger " >
                                                                        <span class="btn-label"  >
                                                                    </span>Annulla</button> 
                                                                </form>
                                                            </div><!-- end col -->

                                                            <div class="col-xl-6">

                                                            </div><!-- end col -->

                                                        </div><!-- end row -->
                                                    </div>
                                                </div>






                </div> <!-- end content -->



               <!-- Footer Start -->
               <?php
                    include 'inc/footer.php';
                 ?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->



        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>



        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>


                <!-- Datatable plugin js -->
                <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
                <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
                <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
                <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

                <script src="assets/libs/jszip/jszip.min.js"></script>
                <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
                <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

                <script src="assets/libs/datatables/buttons.html5.min.js"></script>
                <script src="assets/libs/datatables/buttons.print.min.js"></script>

                <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
                <script src="assets/libs/datatables/dataTables.select.min.js"></script>

                <!-- Datatables init -->
                <script src="assets/js/pages/datatables.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

    </body>
</html>
