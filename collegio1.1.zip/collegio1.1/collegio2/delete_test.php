<?php
include('inc/db.php');
include("inc/auth_session.php");
include("inc/getrole.php");
?>
<!DOCTYPE html>
<html lang="en">
   <!-- head html Topbar -->
   <?php
        include 'inc/head.php';
        ?>
   

    <body>

       <!-- Begin page -->
       <div id="wrapper">
 
 
 <!-- start Topbar -->
 <?php
 include 'inc/topbar.php';
 ?>

   <!-- end Topbar -->

   <!-- ========== Left Sidebar Start ========== -->
 <?php
 if ($UserROLE == 'ADMIN') {

 include 'inc/left-nav.php';

} elseif ($UserROLE == 'CENTER') {
     include 'inc/left-nav-centers.php';
 } else {

 }

 ?>     
 
 <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">

                                    <h4 class="page-title">Elimina</h4>

                                </div>



                            </div>
                        </div>
                        <!-- end page title -->

                    </div> <!-- end container-fluid -->

                    <div class="col-12">
                                                    <div class="card-box">

                                                        <h4 class="header-title mb-4">Elimina esame</h4>



                                                             <?php
                                                                                     
                                                                                     if(isset($_POST['DELETE_test']))
                                                                                     {
                                                                                         if(isset($_POST['IDStudente'])) {  $studente_id = $_POST['IDStudente'];}
                                                                                         if(isset($_POST['corso'])) {  $corso_id = $_POST['corso'];}
                                                                                         $query1=" DELETE FROM esami WHERE IDStudente ='$studente_id' AND corso = '$corso_id'";
                                                                                         
                                                                                         
                                                                                     
                                                                                     
                                                                                     
                                                                                         if ( ! $conn->query($query1)) {
                                                                                             // Creazione fallita 
                                                                                             echo " Errore  nella cancellazione dell ' utente   $query1  ";
                                                                                             }  else {
                                                                                                 echo " Esame eliminato   ";
                                                                                     
                                                                                             }
                                                                                     }
                                                                                         mysqli_close($conn);
                                                                                     
                                                             ?>




                                                        <div class="row">
                                                            <div class="col-xl-6">
                                                            <form method="post" action="<?=($_SERVER['PHP_SELF'])?>" >



                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">ID Studente</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="ID" name="IDStudente">

                                                                    </small>
                                                                </div>

                                                                <div class="form-group">
                                                                    <label for="exampleInputEmail1">Corso</label>
                                                                    <input class="form-control mb-3" type="text" placeholder="Corso" name="corso">

                                                                    </small>
                                                                </div>


                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Esito</label>
                                                                        <input class="form-control mb-3" type="text" placeholder="Esito" name="esito">

                                                                        </small>
                                                                    </div>


                                                                    <div class="form-group">
                                                                        <input class="form-control mb-3" type="text"  name="UserID" value="<?php echo $UserID; ?>" hidden>
                                                                    </div>

                                                                    <div class="form-group">
                                                                        <input class="form-control mb-3" type="text"  name="UserROLE" value="<?php echo $UserROLE; ?>" hidden>
                                                                    </div>


                                                                    <button type="submit" class="btn btn-danger" name="DELETE_test">Elimina</button>
                                                                    <button onclick="window.location.href='tests.php'" type="button"  class="btn btn-primary " >
                                                                        <span class="btn-label"  >
                                                                    </span>Annulla</button> 
                                                             </form>
                                                            </div><!-- end col -->

                                                            <div class="col-xl-6">

                                                            </div><!-- end col -->

                                                        </div><!-- end row -->
                                                    </div>
                                                </div>






                </div> <!-- end content -->



                <!-- Footer Start -->
                <?php
                    include 'inc/footer.php';
                 ?>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->

        </div>
        <!-- END wrapper -->



        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>



        <!-- Vendor js -->
        <script src="assets/js/vendor.min.js"></script>


                <!-- Datatable plugin js -->
                <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
                <script src="assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
                <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>

                <script src="assets/libs/datatables/dataTables.buttons.min.js"></script>
                <script src="assets/libs/datatables/buttons.bootstrap4.min.js"></script>

                <script src="assets/libs/jszip/jszip.min.js"></script>
                <script src="assets/libs/pdfmake/pdfmake.min.js"></script>
                <script src="assets/libs/pdfmake/vfs_fonts.js"></script>

                <script src="assets/libs/datatables/buttons.html5.min.js"></script>
                <script src="assets/libs/datatables/buttons.print.min.js"></script>

                <script src="assets/libs/datatables/dataTables.keyTable.min.js"></script>
                <script src="assets/libs/datatables/dataTables.select.min.js"></script>

                <!-- Datatables init -->
                <script src="assets/js/pages/datatables.init.js"></script>
        <!-- App js -->
        <script src="assets/js/app.min.js"></script>

        <!-- include libraries(jQuery, bootstrap) -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <!-- include summernote css/js -->
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

        <script>
          $(document).ready(function() {
              $('#testdesc').summernote();

            //  $('#footer').summernote();
          });
        </script>
    </body>
</html>
