-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 04, 2021 alle 19:08
-- Versione del server: 10.4.18-MariaDB
-- Versione PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `collegio2`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `centers_data`
--

CREATE TABLE `centers_data` (
  `Centers_Data_ID` int(250) NOT NULL,
  `Center_ID` varchar(250) NOT NULL,
  `CenterName` varchar(250) NOT NULL,
  `Telefono` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `esami`
--

CREATE TABLE `esami` (
  `id_esame` int(100) NOT NULL,
  `IDStudente` int(100) NOT NULL,
  `corso` varchar(50) NOT NULL,
  `esito` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `esami`
--

INSERT INTO `esami` (`id_esame`, `IDStudente`, `corso`, `esito`) VALUES
(12, 3456, 'Storia', 25),
(14, 44444, 'matematica', 20);

-- --------------------------------------------------------

--
-- Struttura della tabella `studenti`
--

CREATE TABLE `studenti` (
  `id_studente` int(100) NOT NULL,
  `IDStudente` int(100) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `studenti`
--

INSERT INTO `studenti` (`id_studente`, `IDStudente`, `nome`, `cognome`, `username`, `email`, `password`) VALUES
(8, 3456, 'ciro', 'ppone', 'ciro1', 'ciro@ppone.it', 'ciro123');

-- --------------------------------------------------------

--
-- Struttura della tabella `usersroles`
--

CREATE TABLE `usersroles` (
  `User_id` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `User_email_address` varchar(150) NOT NULL,
  `User_password` varchar(150) NOT NULL,
  `Account_created_on` datetime NOT NULL,
  `User_ROLE` varchar(250) DEFAULT NULL,
  `Account_Status` varchar(20) NOT NULL DEFAULT 'Attivo'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `usersroles`
--

INSERT INTO `usersroles` (`User_id`, `Username`, `User_email_address`, `User_password`, `Account_created_on`, `User_ROLE`, `Account_Status`) VALUES
(2, 'marian', 'marian@libero.it', 'e792cd9665119b1244e8afcf36fb5f48', '2020-06-09 03:46:08', 'ADMIN', 'Attivo'),
(30, 'ciro1', 'ciro@ppone.it', '15bf91a74f7a790ad5e4804fad068c52', '2021-05-03 15:14:32', 'CENTER', 'Attivo');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `centers_data`
--
ALTER TABLE `centers_data`
  ADD PRIMARY KEY (`Centers_Data_ID`);

--
-- Indici per le tabelle `esami`
--
ALTER TABLE `esami`
  ADD PRIMARY KEY (`id_esame`);

--
-- Indici per le tabelle `studenti`
--
ALTER TABLE `studenti`
  ADD PRIMARY KEY (`id_studente`);

--
-- Indici per le tabelle `usersroles`
--
ALTER TABLE `usersroles`
  ADD PRIMARY KEY (`User_id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `centers_data`
--
ALTER TABLE `centers_data`
  MODIFY `Centers_Data_ID` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4568;

--
-- AUTO_INCREMENT per la tabella `esami`
--
ALTER TABLE `esami`
  MODIFY `id_esame` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT per la tabella `studenti`
--
ALTER TABLE `studenti`
  MODIFY `id_studente` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT per la tabella `usersroles`
--
ALTER TABLE `usersroles`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
